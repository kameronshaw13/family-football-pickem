# Division I college logo color comparison — preliminary audit
Date: 2026-11-18. Full 365-school comparison of ESPN and CBS logo IMAGE COLORS.

## IMPORTANT LIMITATION
This is a relative pixel-color comparison to independent published reference
palettes, NOT a 365-school certification against each institution's licensed
athletics master artwork. Tightknit's 365-school set chiefly links to
teamcolorcodes.com and its 'verified' or 'corrected' labels only mean the
reference values were checked against the cited source. Some academic
and athletic sub-brands publish different approved color values.

NO logo selections or production app settings were changed in this audit.

## Fair primary-to-primary results (ESPN PNG vs CBS standard SVG)
- Near tie (difference below 2.5 CIELAB DeltaE units): 176
- CBS closer to independently compiled reference: 61
- CBS slight edge (difference 2.5–5.9): 44
- ESPN closer: 56
- ESPN slight edge: 25
- Not scorable for both: 3

If allowing CBS's alternate SVG as a second choice instead of only its standard:
- Near tie 175; CBS closer 64; CBS slight edge 43;
- ESPN closer 56; ESPN slight edge 24; not scorable 3.
Picking the best of two CBS assets inherently gives CBS a small advantage.

## Algorithm
1. Current 365 Division I schools: ESPN mens-college-basketball team index,
   groups=50 and limit=500.
2. ESPN logo: a.espncdn.com/i/teamlogos/ncaa/500/{ESPN_ID}.png.
3. CBS assets: sports.cbsimg.net/fly/images/team-logos/{CBS_ID}.svg and
   /alt/{CBS_ID}.svg using the app's verified identity mapping.
4. Reference colors: Tightknit 365-school dataset (checked Nov 14, 2026),
   with per-row source URL. 28 ESPN/Tightknit naming differences were
   reconciled through explicit school aliases, not arbitrary fuzzy matches.
5. Render SVGs to RGBA, sample visible chromatic pixels, convert to CIELAB,
   calculate average nearest-reference color distance (clipped at DeltaE 80).
   Smaller distance means more closely matched sampled brand colors.
6. A 2.5 DeltaE score difference is called 'Near tie'; 2.5–5.9 a
   'slight edge'; >=6 a 'closer' result. These are audit thresholds,
   not industry proofs of correctness.

Important caveats: An alternate authorized colorway or newer mark can
look off-palette but still be completely valid. Neutral white/black details,
gradients and anti-aliasing affect scores. This test does NOT confirm
whether both images depict the same logo design, official licensing,
correct trademark, historic status, or whether the reference palette is current.

## Reading the CSV
- direct_standard_result: FAIR ESPN vs CBS STANDARD comparison.
- direct_standard_gap: absolute gap in average color distance.
- winner: ESPN vs BEST OF CBS standard/alternate, which is a different
  and modestly CBS-favorable comparison.
- espn_distance / cbs_standard_distance / cbs_alternate_distance:
  lower is closer to the reference primary/secondary color palette.
- reference_primary / reference_secondary / reference_source:
  external palette and original source for manual verification.
- espn_team_color: ESPN's metadata color; may differ from actual logo pixels.
- espn_metadata_vs_reference_rgb_distance:
  Euclidean RGB distance (NOT DeltaE); 126 schools were >=50, so
  ESPN metadata cannot itself be used as a certified official reference.
- school_brand_guide_url and note:
  primary institutional sources examined for selected potentially
  conflicting examples, not a claim of official audits for all 365.
- manual_review_priority:
  triage, not a reliability certification.
- source URLs link directly to the actual compared image assets.

## Institutional sources checked separately (selected examples)
Michigan State: https://brand.msu.edu/visual/color-palette
Wichita State: https://goshockers.com/sports/2015/5/27/Branding.aspx
Clemson: https://www.clemson.edu/brand/color/
Duke: https://brand.duke.edu/colors/
Oregon: https://communications.uoregon.edu/uo-brand/visual-identity/colors
Ohio State: https://bux.osu.edu/color/primary-colors/

Caution: Oregon's published UO web green (#007030) differs from a
common athletics-reference green (#154733). Duke publishes both
Academic Navy (#012169) and Athletics Royal Blue (#00539B).
Ohio State publishes scarlet #BA0C2F while the external compilation
used here lists #BB0000. These genuine palette discrepancies need
official athletics artwork checks before setting app defaults.

## Data source URLs
ESPN D1: https://site.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/teams?groups=50&limit=500
CBS mapping: https://github.com/kameronshaw13/family-football-pickem/blob/main/lib/cbsLogos.ts
Colors: https://tightknit.ai/team-colors.json
Color reference sources: row-specific, mostly teamcolorcodes.com

## Recommendation
Keep existing manually chosen logos unchanged. Do NOT bulk-publish
this preliminary comparison as 'official'. Prefer a school's official
athletics logo download if available, then officially licensed
institutional marks, and use source/pixel scores only as triage.
